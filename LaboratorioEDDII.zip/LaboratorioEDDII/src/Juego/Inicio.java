/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Juego;


import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author marqu
 */
public class Inicio extends javax.swing.JFrame {

    public Inicio() {
        initComponents();
         
        this.setLocationRelativeTo(null);
        setImageLabel(fondo, "src/Fondos/arbol.gif");
    }

    public void setImageLabel(JLabel fondo, String root) {
        if (root != null) {
            ImageIcon image = new ImageIcon(root);
            Icon icon = new ImageIcon(image.getImage().getScaledInstance(fondo.getWidth(), fondo.getHeight(), Image.SCALE_DEFAULT));
            fondo.setIcon(icon);
            this.repaint();
        } else {
            System.out.println("La imagen es nula.");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnInicio = new javax.swing.JButton();
        btnReglas = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnInicio.setText("INICIO");
        btnInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicioActionPerformed(evt);
            }
        });
        jPanel1.add(btnInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 170, 130, -1));

        btnReglas.setText("REGLAS");
        btnReglas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReglasActionPerformed(evt);
            }
        });
        jPanel1.add(btnReglas, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 220, 130, -1));

        btnSalir.setText("SALIR");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        jPanel1.add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 270, 130, -1));

        fondo.setText("jLabel1");
        jPanel1.add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 690, 458));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicioActionPerformed
              this.dispose(); // Close the current Inicio frame
        Frame nuevoFrame = new Frame();
        nuevoFrame.setVisible(true);
    }//GEN-LAST:event_btnInicioActionPerformed

    private void btnReglasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReglasActionPerformed
       JOptionPane.showMessageDialog(null, "El juego consiste en avanzar por un árbol de niveles resolviendo acertijos. En cada nivel,"
               + " \nse presenta un acertijo con varias opciones de respuesta. "
               + "\nEl jugador debe seleccionar la opción correcta para avanzar al siguiente nivel. "
               + "\nSi la respuesta es incorrecta, el jugador debe intentarlo nuevamente hasta acertar."
               + "\nUna vez que el jugador resuelve el acertijo correctamente,"
               + "\npuede elegir si avanzar hacia la izquierda o la derecha, dependiendo de las opciones disponibles en el árbol. "
               + "\nA medida que el jugador progresa, la imagen y los botones se actualizan, reflejando su avance."
               + "\nEl objetivo es llegar al final del árbol resolviendo todos los acertijos correctamente.");
    }//GEN-LAST:event_btnReglasActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws IOException {
         ArbolAVL a1 = new ArbolAVL();
        a1.crearArbolConNumeros();
           
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnInicio;
    private javax.swing.JButton btnReglas;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel fondo;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
