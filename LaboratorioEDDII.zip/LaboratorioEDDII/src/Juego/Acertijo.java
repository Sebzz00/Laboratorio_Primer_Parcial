
package Juego;
public class Acertijo {
     public String pista;
     public String respuesta;
     public String [] opciones ; 

    public Acertijo(String pista, String respuesta , String[] opciones) {
        this.pista = pista;
        this.respuesta = respuesta;
        this.opciones = opciones ; 
    }
    
}
