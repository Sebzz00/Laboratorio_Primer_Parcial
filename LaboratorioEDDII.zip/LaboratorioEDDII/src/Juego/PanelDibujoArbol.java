
package Juego;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class PanelDibujoArbol extends JPanel {
    private Nodo raiz;

    public PanelDibujoArbol(Nodo raiz) {
        this.raiz = raiz;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (raiz != null) {
            dibujarArbol(g, raiz, getWidth() / 2, 50, getWidth() / 4);
        }
    }

    private void dibujarArbol(Graphics g, Nodo nodo, int x, int y, int offset) {
        if (nodo == null) {
            return;
        }

        // Dibujar el nodo actual
        g.setColor(Color.GREEN);
        g.fillOval(x - 15, y - 15, 30, 30);
        g.setColor(Color.BLACK);
        g.drawString(String.valueOf(nodo.dato), x - 5, y + 5);

        // Dibujar la rama izquierda
        if (nodo.izq != null) {
            g.drawLine(x, y, x - offset, y + 50);
            dibujarArbol(g, nodo.izq, x - offset, y + 50, offset / 2);
        }

        // Dibujar la rama derecha
        if (nodo.der != null) {
            g.drawLine(x, y, x + offset, y + 50);
            dibujarArbol(g, nodo.der, x + offset, y + 50, offset / 2);
        }
    }
}
