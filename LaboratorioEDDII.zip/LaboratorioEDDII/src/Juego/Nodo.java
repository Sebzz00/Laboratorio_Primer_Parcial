package Juego;

/**
 *
 * @author gutierrezdavid
 */
public class Nodo {

    int dato;
    int FE;
    Nodo izq;
    Nodo der;
    int info;
    Level nivel;

    public Nodo(int dato) {
        this.FE = 1;
        this.dato = dato;
        this.izq = null;
        this.der = null;
        this.nivel= new Level(dato);
    }
    
    

}
