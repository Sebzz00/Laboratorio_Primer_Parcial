package Juego;

//package clase9;
//
//import java.io.IOException;
//
//public class Clase9 {
//
//    public static void main(String[] args) throws IOException {
//        ArbolAVL a1 = new ArbolAVL();
//        a1.crearArbolConNumeros();
//        a1.TreePrinter();
//        System.out.println(a1.encontrarHojasUltimoNivel().toString());
//    }
//    
//}
