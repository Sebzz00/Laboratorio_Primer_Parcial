/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Juego;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author orlandopalma
 */
public class Frame extends javax.swing.JFrame {

    private static Nodo raizFrame;
    private Nodo nodoActual;
    private boolean acerState = true;
    private ArrayList<String> recorrido = new ArrayList<>();
    private ArrayList<String> decisiones = new ArrayList<>();

    public Frame() {
        initComponents();
        inicializarJuego();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        butIzq = new javax.swing.JButton();
        butDer = new javax.swing.JButton();
        fondo = new javax.swing.JLabel();
        lvlLabel = new javax.swing.JLabel();
        btnEstado = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        butIzq.setText("Izquierda");
        butIzq.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butIzqActionPerformed(evt);
            }
        });

        butDer.setText("Derecha");
        butDer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butDerActionPerformed(evt);
            }
        });

        fondo.setText("Fondo");

        lvlLabel.setText("NIvel");

        btnEstado.setText("Estado");
        btnEstado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEstadoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(butIzq)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lvlLabel)
                .addGap(77, 77, 77)
                .addComponent(butDer)
                .addGap(65, 65, 65)
                .addComponent(btnEstado)
                .addGap(77, 77, 77))
            .addGroup(layout.createSequentialGroup()
                .addComponent(fondo, javax.swing.GroupLayout.PREFERRED_SIZE, 559, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(fondo, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(butDer)
                    .addComponent(lvlLabel)
                    .addComponent(btnEstado)
                    .addComponent(butIzq))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void butDerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butDerActionPerformed
        if (nodoActual.der != null) {
            if (mostrarAcertijo(nodoActual)) {
                System.out.println("Avanzando a nodo derecho desde nivel: " + nodoActual.nivel.code);
                nodoActual = nodoActual.der;
                System.out.println("Nuevo nodo actual: " + nodoActual.nivel.code);
                actualizarInterfaz("Derecha");
            } else {
                System.out.println("No se avanzó al nodo derecho");
            }
        } else {
            System.out.println("No hay nodo derecho");
        }

    }//GEN-LAST:event_butDerActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated

    }//GEN-LAST:event_formWindowActivated

    private void butIzqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butIzqActionPerformed
        if (nodoActual.izq != null) {
            if (mostrarAcertijo(nodoActual)) {
                System.out.println("Avanzando a nodo izquierdo desde nivel: " + nodoActual.nivel.code);
                nodoActual = nodoActual.izq;
                System.out.println("Nuevo nodo actual: " + nodoActual.nivel.code);
                actualizarInterfaz("Izquierda");
            } else {
                System.out.println("No se avanzó al nodo izquierdo");
            }
        } else {
            System.out.println("No hay nodo izquierdo");
        }

    }//GEN-LAST:event_butIzqActionPerformed

    private void btnEstadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEstadoActionPerformed
        StringBuilder estado = new StringBuilder();
        estado.append("Recorrido: [");

        // Recorrer las listas y formatear la salida
        for (int i = 0; i < recorrido.size(); i++) {
            estado.append(recorrido.get(i));
            if (i < recorrido.size() - 1) {
                estado.append(", ");
            }
        }
        estado.append("]\nDecisiones: [");

        for (int i = 0; i < decisiones.size(); i++) {
            estado.append(decisiones.get(i));
            if (i < decisiones.size() - 1) {
                estado.append(", ");
            }
        }
        estado.append("]");
        JOptionPane.showMessageDialog(this, estado.toString(), "Estado del Jugador", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnEstadoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws IOException {

        ArbolAVL a1 = new ArbolAVL();
        a1.crearArbolConNumeros();
        a1.TreePrinter();
        raizFrame = ArbolAVL.raiz;

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Frame().setVisible(true);
            }
        });
    }

    private void inicializarJuego() {
       System.out.println("Inicializando juego");
    if (raizFrame == null) {
        System.out.println("raizFrame es nulo. Inicializando ArbolAVL.");
        try {
            ArbolAVL a1 = new ArbolAVL();
            a1.crearArbolConNumeros();
            raizFrame = ArbolAVL.raiz;
            System.out.println("ArbolAVL inicializado correctamente. Nodo raíz: " + raizFrame.nivel.code);
            
            // Aquí podrías agregar código para guardar el estado del árbol
            // guardarEstadoArbol(raizFrame);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al inicializar el juego: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    } else {
        System.out.println("Usando ArbolAVL existente. Nodo raíz: " + raizFrame.nivel.code);
    }
    nodoActual = raizFrame;
    actualizarInterfaz("Inicio");
    }

    private void actualizarInterfaz(String direccion) {
        if (nodoActual == null) {
            System.out.println("Error: nodoActual es nulo");
            JOptionPane.showMessageDialog(this, "Error al actualizar la interfaz: nodoActual es nulo", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        System.out.println("Actualizando interfaz para nivel: " + nodoActual.nivel.code);
        recorrido.add("Nivel " + nodoActual.nivel.code);
        decisiones.add(direccion);

        setImageLabel(fondo, nodoActual.nivel.imagen);
        lvlLabel.setText("Nivel: " + nodoActual.nivel.code);

        verificarBotones();
        repaint();
        revalidate();
        System.out.println("Interfaz actualizada");
    }

    public void verificarBotones() {
        System.out.println("Verificando botones para nivel: " + nodoActual.nivel.code);
        butDer.setVisible(nodoActual.der != null);
        butIzq.setVisible(nodoActual.izq != null);

        if (nodoActual.der == null && nodoActual.izq == null) {
            System.out.println("Llegada a nodo hoja. Abriendo FrameLlegada.");
            FrameLlegada frameLlegada = new FrameLlegada(ArbolAVL.getRaiz(), recorrido, decisiones);
            frameLlegada.setVisible(true);
            this.setVisible(false);
        }
    }

    public void setImageLabel(JLabel fondo, BufferedImage image) {
        if (image != null) {
            ImageIcon icon = new ImageIcon(image.getScaledInstance(fondo.getWidth(), fondo.getHeight(), Image.SCALE_DEFAULT));
            fondo.setIcon(icon);
            System.out.println("Imagen actualizada para nivel: " + nodoActual.nivel.code);
        } else {
            System.out.println("La imagen es nula para el nivel: " + nodoActual.nivel.code);
            // Opcionalmente, podrías establecer una imagen por defecto aquí
            // fondo.setIcon(new ImageIcon("ruta/a/imagen/por/defecto.png"));
        }
    }

    public boolean mostrarAcertijo(Nodo nodo) {
        System.out.println("Mostrando acertijo para nodo: " + nodo.nivel.code);
        String pista = nodo.nivel.acertijo.pista;
        String[] opciones = nodo.nivel.acertijo.opciones;
        String respuestaCorrecta = nodo.nivel.acertijo.respuesta;

        int seleccion = JOptionPane.showOptionDialog(
                this,
                pista,
                "Acertijo",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                icono("/Fondos/lupa.jpeg", 40, 40),
                opciones,
                opciones[0]
        );

        if (seleccion == -1) {
            System.out.println("Usuario cerró el diálogo");
            return false;
        }

        String opcionSeleccionada = opciones[seleccion];

        if (opcionSeleccionada.equals(respuestaCorrecta)) {
            System.out.println("Respuesta correcta");
            JOptionPane.showMessageDialog(this, "¡Respuesta correcta!");
            return true;
        } else {
            System.out.println("Respuesta incorrecta");
            JOptionPane.showMessageDialog(this, "Respuesta incorrecta. Intenta de nuevo.");
            return false;
        }
    }

    public Icon icono(String root, int w, int h) {
        Icon img = new ImageIcon(new ImageIcon(getClass().
                getResource(root)).getImage().getScaledInstance(w, h, java.awt.Image.SCALE_SMOOTH));
        return img;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEstado;
    private javax.swing.JButton butDer;
    private javax.swing.JButton butIzq;
    private javax.swing.JLabel fondo;
    private javax.swing.JLabel lvlLabel;
    // End of variables declaration//GEN-END:variables
}
