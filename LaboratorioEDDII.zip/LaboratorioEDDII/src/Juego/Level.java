package Juego;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

public class Level {

    int code;
    BufferedImage imagen;
    Acertijo acertijo;


    public Level(int code) {
        this.code = code;
        this.imagen = ArbolAVL.fondos.get(code-1);
        this.acertijo = ArbolAVL.acertijos.get(code - 1);
    }



}
