package Juego;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.ArrayList;
import java.util.Collections;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class ArbolAVL {

   public  static Nodo raiz;
    public static ArrayList<BufferedImage> fondos = new ArrayList<>();
    public static ArrayList<Acertijo> acertijos = new ArrayList<>();

    public ArbolAVL() {
        this.raiz = null;
    }

    public static Nodo getRaiz() {
        return raiz;
    }
    // Función para insertar números del 1 al 20 de manera aleatoria
    public void crearArbolConNumeros() throws IOException {
        llenarArraylist();
        acertijos();
        ArrayList<Integer> numeros = new ArrayList<>();
        for (int i = 1; i <= 20; i++) {
            numeros.add(i);
        }
        Collections.shuffle(numeros); // Mezclamos para tener un orden aleatorio
        for (int num : numeros) {
            raiz = insertar(raiz, num);
        }
        raiz.info = 21;
        raiz.nivel.code = 21;
        ArrayList<Nodo> hojas = encontrarHojasUltimoNivel();
        Random random = new Random();
        int numeroAleatorio = random.nextInt(hojas.size()) + 1;
        for (int i = 0; i < hojas.size(); i++) {
            if (i == numeroAleatorio - 1) {
                hojas.get(i).info = 22;
                hojas.get(i).nivel.code = 22;
            } else {
                hojas.get(i).info = 23;
                hojas.get(i).nivel.code = 23;

            }
        }
    }

    // Función para encontrar las hojas en el último nivel
    public ArrayList<Nodo> encontrarHojasUltimoNivel() {
        ArrayList<Nodo> hojas = new ArrayList<>();
        int altura = alturaArbol(raiz);
        encontrarHojasUltimoNivel(raiz, 1, altura, hojas);
        return hojas;
    }

    // Función recursiva para añadir hojas al ArrayList
    private void encontrarHojasUltimoNivel(Nodo nodo, int nivelActual, int altura, ArrayList<Nodo> hojas) {
        if (nodo == null) {
            return;
        }
        // Si es una hoja y está en el último nivel
        if (nodo.izq == null && nodo.der == null && nivelActual == altura) {
            hojas.add(nodo);
        }
        // Llamada recursiva para hijos izquierdo y derecho
        encontrarHojasUltimoNivel(nodo.izq, nivelActual + 1, altura, hojas);
        encontrarHojasUltimoNivel(nodo.der, nivelActual + 1, altura, hojas);
    }

    // Función para insertar en el árbol AVL y manejar las rotaciones
    private Nodo insertar(Nodo nodo, int valor) {
        if (nodo == null) {
            Nodo nodo1 = new Nodo(valor);
            nodo1.info = valor;
            return nodo1;

        }

        // Inserción estándar de BST (Binary Search Tree)
        if (valor < nodo.dato) {
            nodo.izq = insertar(nodo.izq, valor);
        } else if (valor > nodo.dato) {
            nodo.der = insertar(nodo.der, valor);
        } else {
            return nodo; // No se permiten duplicados
        }

        // Actualizar el factor de equilibrio (FE)
        nodo.FE = 1 + Math.max(alturaArbol(nodo.izq), alturaArbol(nodo.der));

        // Calcular el balance del nodo actual
        int balance = calcularFE(nodo);

        // Caso 1: Desbalance a la izquierda
        if (balance > 1 && valor < nodo.izq.dato) {
            return rotarDerecha(nodo);
        }

        // Caso 2: Desbalance a la derecha
        if (balance < -1 && valor > nodo.der.dato) {
            return rotarIzquierda(nodo);
        }

        // Caso 3: Desbalance izquierda-derecha
        if (balance > 1 && valor > nodo.izq.dato) {
            nodo.izq = rotarIzquierda(nodo.izq);
            return rotarDerecha(nodo);
        }

        // Caso 4: Desbalance derecha-izquierda
        if (balance < -1 && valor < nodo.der.dato) {
            nodo.der = rotarDerecha(nodo.der);
            return rotarIzquierda(nodo);
        }

        return nodo;
    }

    // Función de rotación a la derecha
    private Nodo rotarDerecha(Nodo y) {
        Nodo x = y.izq;
        Nodo T2 = x.der;

        // Realizar la rotación
        x.der = y;
        y.izq = T2;

        // Actualizar alturas
        y.FE = Math.max(alturaArbol(y.izq), alturaArbol(y.der)) + 1;
        x.FE = Math.max(alturaArbol(x.izq), alturaArbol(x.der)) + 1;

        return x;
    }

    // Función de rotación a la izquierda
    private Nodo rotarIzquierda(Nodo x) {
        Nodo y = x.der;
        Nodo T2 = y.izq;

        // Realizar la rotación
        y.izq = x;
        x.der = T2;

        // Actualizar alturas
        x.FE = Math.max(alturaArbol(x.izq), alturaArbol(x.der)) + 1;
        y.FE = Math.max(alturaArbol(y.izq), alturaArbol(y.der)) + 1;

        return y;
    }

    // Función para calcular el factor de equilibrio
    private int calcularFE(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }
        return alturaArbol(nodo.izq) - alturaArbol(nodo.der);
    }

    // Función para calcular la altura del árbol
    private int alturaArbol(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }
        return nodo.FE;
    }

    public static void imprimirArbol(int[][] M, Nodo root, int col, int row, int height) {
        if (root == null) {
            return;
        }
        M[row][col] = root.nivel.code;
        imprimirArbol(M, root.izq, col - (int) Math.pow(2, height - 2), row + 1, height - 1);
        imprimirArbol(M, root.der, col + (int) Math.pow(2, height - 2), row + 1, height - 1);
    }

    public static int getcol(int h) {
        if (h == 1) {
            return 1;
        }
        return getcol(h - 1) + getcol(h - 1) + 1;
    }

    public void TreePrinter() {
        int h = alturaArbol(this.raiz);
        int col = getcol(h);
        int[][] M = new int[h][col];
        imprimirArbol(M, this.raiz, col / 2, 0, h);
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < col; j++) {
                if (M[i][j] == 0) {
                    System.out.print("  ");
                } else {
                    System.out.print(M[i][j] + " ");
                }
            }
            System.out.println();
        }
    }
//    public static void llenarArraylist() throws IOException {
//    String imagePath = "/Fondos/imagen3.jpeg";
//    if (Level.class.getResource(imagePath) != null) {
//        System.out.println("Imagen encontrada: " + Level.class.getResource(imagePath));
//        fondos.add(ImageIO.read(Level.class.getResourceAsStream(imagePath)));
//    } else {
//        System.out.println("No se encontró la imagen: " + imagePath);
//    }
//}

    public static void llenarArraylist() throws IOException {
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen1.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen2.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen3.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen4.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen5.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen6.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen7.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen8.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen9.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen10.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen11.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen12.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen13.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen14.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen15.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen16.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen17.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen18.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen19.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen20.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen21.jpeg")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen22.png")));
        fondos.add(ImageIO.read(Level.class.getResourceAsStream("/Fondos/imagen23.jpg")));
    }

   public static void acertijos() {
    String[] awd1 = {"El árbol genealógico", "El abeto", "El sauce"};
    String[] awd2 = {"El abeto", "El pino", "El manzano"};
    String[] awd3 = {"Un árbol", "Un tronco", "Un arbusto"};
    String[] awd4 = {"Un árbol de libros", "Un libro grande", "Un roble"};
    String[] awd5 = {"El llanto (de la llorona)", "El sauce", "El álamo"};
    String[] awd6 = {"Un árbol de piedra", "Un árbol inmortal", "Un árbol de hielo"};
    String[] awd7 = {"El sauce", "El álamo", "El roble"};
    String[] awd8 = {"El pino de Bristlecone", "El roble", "El cedro"};
    String[] awd9 = {"El árbol de navidad", "El abeto", "El álamo"};
    String[] awd10 = {"El manzano", "El árbol genealógico", "El sauce"};
    String[] awd11 = {"El árbol de las matemáticas", "El roble", "El árbol genealógico"};
    String[] awd12 = {"El eucalipto", "El pino", "El abeto"};
    String[] awd13 = {"Sí, hace ruido", "No, no hace ruido", "Solo si lo escuchas"};
    String[] awd14 = {"El memoria", "El pino", "El sauce"};
    String[] awd15 = {"El árbol de peligro de extinción", "El roble", "El abeto"};
    String[] awd16 = {"El árbol de Navidad", "El pino", "El sauce"};
    String[] awd17 = {"El árbol de papel", "El abeto", "El árbol inmortal"};
    String[] awd18 = {"El líder", "El roble", "El árbol genealógico"};
    String[] awd19 = {"El árbol de pie", "El abeto", "El tronco"};
    String[] awd20 = {"Un árbol de madera", "Un árbol inmortal", "Un árbol de piedra"};

    acertijos.add(new Acertijo("¿Qué árbol es conocido por su gran sombra, pero no tiene hojas?", "El árbol genealógico", awd1));
    acertijos.add(new Acertijo("¿Qué árbol siempre lleva un abrigo?", "El abeto", awd2));
    acertijos.add(new Acertijo("¿Qué se encuentra en un bosque, tiene una corteza dura, y nunca cuenta historias?", "Un árbol", awd3));
    acertijos.add(new Acertijo("¿Qué tipo de árbol puedes encontrar en una biblioteca?", "Un árbol de libros", awd4));
    acertijos.add(new Acertijo("¿Cuál es el árbol más triste?", "El llanto (de la llorona)", awd5));
    acertijos.add(new Acertijo("En un bosque hay un árbol que nunca se mueve. ¿Qué es?", "Un árbol de piedra", awd6));
    acertijos.add(new Acertijo("¿Qué árbol tiene un pie en el agua y otro en la tierra?", "El sauce", awd7));
    acertijos.add(new Acertijo("¿Cuál es el árbol más antiguo?", "El pino de Bristlecone", awd8));
    acertijos.add(new Acertijo("¿Qué árbol siempre está en el aire?", "El árbol de navidad", awd9));
    acertijos.add(new Acertijo("Soy un árbol que da fruta, pero nunca la como. ¿Qué soy?", "El manzano", awd10));
    acertijos.add(new Acertijo("¿Qué árbol crece más rápido?", "El árbol de las matemáticas", awd11));
    acertijos.add(new Acertijo("¿Qué tipo de árbol da sombra pero no frutas?", "El eucalipto", awd12));
    acertijos.add(new Acertijo("Si un árbol cae en un bosque y no hay nadie para oírlo, ¿hace ruido?", "Sí, hace ruido", awd13));
    acertijos.add(new Acertijo("¿Qué árbol tiene una gran memoria?", "El memoria", awd14));
    acertijos.add(new Acertijo("¿Qué árbol siempre está en peligro?", "El árbol de peligro de extinción", awd15));
    acertijos.add(new Acertijo("¿Qué árbol tiene hojas que nunca caen?", "El árbol de Navidad", awd16));
    acertijos.add(new Acertijo("¿Qué árbol se convierte en papel?", "El árbol de papel", awd17));
    acertijos.add(new Acertijo("¿Qué tipo de árbol es siempre un líder?", "El líder", awd18));
    acertijos.add(new Acertijo("¿Cuál es el árbol que nunca habla, pero siempre está 'de pie'?", "El árbol de pie", awd19));
    acertijos.add(new Acertijo("En un bosque hay un árbol que no crece, no se mueve y no da sombra. ¿Qué es?", "Un árbol de madera", awd20));

}

    


      
    

    

}
